export let configFTP = {
  host: "", // Адрес FTP-сервера
  user: "", // Имя пользователя
  password: "", // Пароль
  parallel: 5 // Кол-во одновременных потоков
}